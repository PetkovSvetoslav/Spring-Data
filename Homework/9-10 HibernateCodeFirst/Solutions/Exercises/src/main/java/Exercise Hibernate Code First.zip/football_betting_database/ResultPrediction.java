package football_betting_database;

public enum ResultPrediction {
    HOME_TEAM_WIN,
    AWAY_TEAM_WIN,
    DRAW_GAME
}