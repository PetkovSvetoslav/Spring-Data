package bills_payment_system.billing_dedatils.cards;

public enum CardType {
    SILVER,
    GOLD,
    PLATINUM
}