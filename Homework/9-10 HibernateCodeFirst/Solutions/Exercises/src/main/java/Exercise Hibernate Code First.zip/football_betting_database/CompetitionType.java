package football_betting_database;

public enum CompetitionType {
    LOCAL,
    NATIONAL,
    INTERNATIONAL
}