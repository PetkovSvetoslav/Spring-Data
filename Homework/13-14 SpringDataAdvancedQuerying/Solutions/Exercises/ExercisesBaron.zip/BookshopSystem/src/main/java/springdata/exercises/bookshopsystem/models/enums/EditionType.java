package springdata.exercises.bookshopsystem.models.enums;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
