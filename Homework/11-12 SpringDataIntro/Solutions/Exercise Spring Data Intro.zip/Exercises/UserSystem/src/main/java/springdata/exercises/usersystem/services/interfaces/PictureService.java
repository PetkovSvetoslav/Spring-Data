package springdata.exercises.usersystem.services.interfaces;

import springdata.exercises.usersystem.models.gallery.Picture;

public interface PictureService {
    void registerPicture(Picture picture);
}
