package springdata.exercises.usersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
