package springdata.exercises.bookshopsystem.models.enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
