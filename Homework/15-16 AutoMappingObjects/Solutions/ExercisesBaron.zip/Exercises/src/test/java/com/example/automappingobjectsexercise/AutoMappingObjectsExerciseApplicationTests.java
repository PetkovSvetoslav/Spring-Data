package com.example.automappingobjectsexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoMappingObjectsExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
